numbers = [1, 3, 8]
for number in numbers:
    print("The current number is:")
    print(number)