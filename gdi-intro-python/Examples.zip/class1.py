input_value = raw_input("Enter a radius:")
radius = float(input_value)
area = 3.14159 * radius ** 2
print("The area of a circle with radius " + input_value + " is:")
print(area)
