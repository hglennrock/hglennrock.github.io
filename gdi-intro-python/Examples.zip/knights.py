def shrubbery():
    print("I am a shrubbery")

def ni():
    print("Ni!" * 3)
