def find_rectangle_area(width, height):
    return width * height

area = find_rectangle_area(3, 4)
# area is set to the value 12
print('The area is ' + str(area))