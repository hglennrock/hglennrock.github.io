def plus_5(x):
    return x + 5

y = plus_5(4)

print(y)